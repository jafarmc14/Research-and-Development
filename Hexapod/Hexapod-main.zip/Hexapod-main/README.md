# Hexapod robot for fire fighting robot competition
